public interface TemperatureDisplay {
    void updateWeather(double celsius, double kelvin, double fahrenheit, double pressureInches,
            double pressureMillibars);
}
