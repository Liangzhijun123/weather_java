public interface TemperatureDisplay {
    void updateTemperatures(double celsius, double kelvin);
}
